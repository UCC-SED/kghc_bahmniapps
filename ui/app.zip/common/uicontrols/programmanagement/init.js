'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.UIControls = Bahmni.Common.UIControls || {};
Bahmni.Common.UIControls.ProgramManagement = Bahmni.Common.UIControls.ProgramManagement || {};

angular.module('bahmni.common.uicontrols.programmanagment', []);
