'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.UIControls = Bahmni.Common.UIControls || {};

angular.module('bahmni.common.uicontrols', []);
