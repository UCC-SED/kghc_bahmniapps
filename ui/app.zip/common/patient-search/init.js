angular.module('bahmni.common.patientSearch', ['bahmni.common.patient', 'infinite-scroll']);

