angular.module('bahmni.common.photoCapture', []);
