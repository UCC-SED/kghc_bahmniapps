angular.module('bahmni.common.gallery', []);
