'use strict';
var Bahmni = Bahmni || {};
Bahmni.Common = Bahmni.Common || {};
Bahmni.Common.Offline = Bahmni.Common.Offline || {};
Bahmni.Common.Offline.dbNameCondition = Bahmni.Common.Offline.dbNameCondition || {};

angular.module('bahmni.common.offline', ['bahmni.common.util', 'bahmni.common.models', 'FredrikSandell.worker-pool', 'ngDialog']);
