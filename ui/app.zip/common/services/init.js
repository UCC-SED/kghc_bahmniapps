'use strict';

angular.module('bahmni.common.services', []);
