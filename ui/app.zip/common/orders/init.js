angular.module('bahmni.common.orders', []);
