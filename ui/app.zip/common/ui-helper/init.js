angular.module('bahmni.common.uiHelper', ['ngClipboard']);
