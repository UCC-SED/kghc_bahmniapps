'use strict';

angular.module('bahmni.clinical')
    .controller('AppointmentController', ['$scope', '$q', '$window', '$state', '$translate', 'spinner', 'patientService',
        'messagingService', 'ngDialog', 'appService', '$stateParams',
        function ($scope, $q, $window, $state, $translate, spinner, patientService,
            messagingService, ngDialog, appService, $stateParams) {
            var init = function () {

            };
            init();
        }
    ]);
