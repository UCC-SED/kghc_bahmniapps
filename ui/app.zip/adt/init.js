'use strict';

var Bahmni = Bahmni || {};
Bahmni.ADT = Bahmni.ADT || {};

angular.module('bahmni.adt', ['bahmni.common.conceptSet', 'bahmni.common.logging']);

